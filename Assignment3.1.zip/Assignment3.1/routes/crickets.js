const express = require('express');
const router = express.Router();
const Cricket = require('../models/cricket');

// Get all players
router.get('/', async (req, res) => {
    try {
        const players = await Cricket.find();
        res.json(players);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Get a specific player by ID
router.get('/:id', async (req, res) => {
    try {
        const player = await Cricket.findById(req.params.id);
        res.json(player);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Create a new player
router.post('/', async (req, res) => {
    const player = new Cricket({
        player_name: req.body.player_name,
        team: req.body.team,
        matches_played: req.body.matches_played,
        runs_scored: req.body.runs_scored,
        centuries: req.body.centuries,
        wickets_taken: req.body.wickets_taken,
        touchdown_passes: req.body.touchdown_passes,
        rushing_yards: req.body.rushing_yards,
        field_goals_made: req.body.field_goals_made,
        field_goals_missed: req.body.field_goals_missed,
        sacks: req.body.sacks,
        catches_made: req.body.catches_made
    });

    try {
        const savedPlayer = await player.save();
        res.status(201).json(savedPlayer);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Update a player by ID
router.patch('/:id', async (req, res) => {
    try {
        const player = await Cricket.findById(req.params.id);
        player.sub = req.body.sub;
        const updatedPlayer = await player.save();
        res.json(updatedPlayer);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Delete a player by ID
exports.deletePlayer = function (req, res) {
    const playerId = req.params.id;
    Cricket.deleteOne({ _id: playerId }, function (err, result) {
        if (err) {
            res.status(500).json({ message: err.message });
        } else if (result.deletedCount === 0) {
            res.status(404).json({ message: 'Player not found' });
        } else {
            res.json({ message: 'Player deleted successfully' });
        }
    });
};


module.exports = router;
