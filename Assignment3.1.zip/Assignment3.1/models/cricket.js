const mongoose = require('mongoose');

const cricketSchema = new mongoose.Schema({
    player_name: {
        type: String,
        required: true
    },
    team: {
        type: String,
        required: true
    },
    matches_played: {
        type: Number,
        required: true
    },
    runs_scored: {
        type: Number,
        required: true
    },
    centuries: {
        type: Number,
        required: true
    },
    wickets_taken: {
        type: Number,
        required: true
    },
    touchdown_passes: {
        type: Number,
        required: true
    },
    rushing_yards: {
        type: Number,
        required: true
    },
    field_goals_made: {
        type: Number,
        required: true
    },
    field_goals_missed: {
        type: Number,
        required: true
    },
    sacks: {
        type: Number,
        required: true
    },
    catches_made: {
        type: Number,
        required: true
    },
});

module.exports = mongoose.model('Cricket', cricketSchema);
