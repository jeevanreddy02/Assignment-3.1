const express = require('express');
const mongoose = require('mongoose');
const url = 'mongodb://localhost/JeevanReddyDB';

const app = express();

mongoose.connect(url, { useNewUrlParser: true });
const con = mongoose.connection;

con.on('open', () => {
    console.log('connected...');
});

app.use(express.json());

const cricketRouter = require('./routes/crickets');
app.use('/crickets', cricketRouter);

// Define a route for the root path
app.get('/', (req, res) => {
    res.send('Welcome to the Cricket Team USA Details!');
});

app.listen(9000, () => {
    console.log('Server started');
});
